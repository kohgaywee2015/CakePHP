<?php
	class Post extends AppModel {
		public $belongsTo='Topic';
		
	}
?>